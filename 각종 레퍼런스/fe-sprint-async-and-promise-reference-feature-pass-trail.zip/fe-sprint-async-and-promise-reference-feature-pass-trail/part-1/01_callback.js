const delay = (wait, callback) => {
  setTimeout(callback, wait);
}