import React from 'react';

const Footer = () => {
  return <footer>Copyright @ 2022 Code States</footer>;
};

export default Footer;
